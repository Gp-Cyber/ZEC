#!/bin/sh

# Change the following address to your Zhash addr.
ADDRESS=GNjEhF8dfiCj9JSntTnsovb2c3z2kptfwi

USERNAME=$ADDRESS.Coba
POOL=us1-zcash.flypool.org:3333
SCHEME=zhash

./bminer -uri $SCHEME://$USERNAME@$POOL -api 127.0.0.1:1880
